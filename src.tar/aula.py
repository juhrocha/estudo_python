nome=str(input('Qual é seu nome? '))
if nome == 'Juliana':
    print('Que belo nome!')
elif nome == 'Reinaldo':
    print('É o nome de meu namorado!')
else:
    print('Gostei!')
print('Tenha um bom dia, {}!'.format(nome))