numero_1 = int(input('Digite um número: '))
numero_2 = int(input('Digite outro número: '))
if numero_1 > numero_2:
    print ('O primeiro valor é maior')
elif numero_2 > numero_1:
    print('O segundo valor é maior')
elif numero_1 == numero_2:
    print('Os números são iguais!')
